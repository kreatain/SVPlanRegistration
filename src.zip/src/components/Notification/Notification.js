import React from "react";
import { useSelector } from "react-redux";
import "../../styles/Notification.css";

const Notification = () => {
  const { tasks } = useSelector((state) => state.task);
  const { events } = useSelector((state) => state.event);

  const currentDate = new Date();
  const upcomingThreshold = new Date();
  upcomingThreshold.setDate(currentDate.getDate() + 5);

  const upcomingTasks = tasks.filter((task) => {
    const dueDate = new Date(task.dueDate);
    return dueDate >= currentDate && dueDate <= upcomingThreshold;
  });

  const upcomingEvents = events.filter((event) => {
    const eventDate = new Date(event.event_time);
    return eventDate >= currentDate && eventDate <= upcomingThreshold;
  });

  return (
    <div className="notification-container">
      <h2>Your Notifications</h2>
      <div className="notification-list">
        {/* Task Notifications */}
        {upcomingTasks.length > 0 ? (
          upcomingTasks.map((task) => (
            <div key={task.taskId} className="notification-card taskn-card">
              <p>Your task "{task.taskName}" is due soon.</p>
              <p className="notification-date">
                {new Date(task.dueDate).toLocaleString()}
              </p>
            </div>
          ))
        ) : (
          <p>No upcoming tasks available.</p>
        )}

        {/* Event Notifications */}
        {upcomingEvents.length > 0 ? (
          upcomingEvents.map((event) => (
            <div key={event.event_id} className="notification-card event-card">
              <p>Your event "{event.event_name}" is happening soon.</p>
              <p className="notification-date">
                {new Date(event.event_time).toLocaleString()}
              </p>
            </div>
          ))
        ) : (
          <p>No upcoming events available.</p>
        )}
      </div>
    </div>
  );
};

export default Notification;